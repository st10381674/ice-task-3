/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication10;

import java.util.regex.Pattern;

/**
 *
 * @author RC_Student_lab
 */

public class Login {
    private final String username;
    private final String password;
    private final String firstName;
    private final String lastName;

    public Login(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public boolean checkUsername() {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        return Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$").matcher(password).matches();
    }

    public String registerUser() {
        if (!checkUsername()) {
            return "Username is incorrectly formatted.";
        }
        
        if (!checkPasswordComplexity()) {
            return "Password does not meet the complexity requirements.";
        }

        // Successfully registered
        return "Registration successful!";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    public String returnLoginStatus(boolean isAuthenticated) {
        if (isAuthenticated) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

}
