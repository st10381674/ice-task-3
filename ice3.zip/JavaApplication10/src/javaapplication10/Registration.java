/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication10;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author RC_Student_lab
 */
public class Registration {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter username:");
        String username = scanner.nextLine();

        System.out.println("Enter password:");
        String password = scanner.nextLine();

        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();

        createAccount(username, password, firstName, lastName);
    }

    public static String validateUsername(String username) {
        // Check if username contains an underscore and is no more than 5 characters long
        if (username.contains("_") && username.length() <= 5) {
            return "Username successfully captured";
        } else {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
    }

    public static String validatePassword(String password) {
        // Check password complexity rules using regular expressions
        if (Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$").matcher(password).matches()) {
            return "Password successfully captured";
        } else {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
    }

    public static void createAccount(String username, String password, String firstName, String lastName) {
        // Validate username and password
        String usernameMessage = validateUsername(username);
        String passwordMessage = validatePassword(password);

        // If both username and password are valid, create account
        if ("Username successfully captured".equals(usernameMessage) && "Password successfully captured".equals(passwordMessage)) {
            System.out.println("Account created successfully!");
            System.out.println("Username: " + username);
            System.out.println("First Name: " + firstName);
            System.out.println("Last Name: " + lastName);
        } else {
            System.out.println("Account creation failed!");
            System.out.println(usernameMessage);
            System.out.println(passwordMessage);
        }
    }
}
